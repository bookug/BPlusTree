/* Information about this file */

#include "Hash.h"
using namespace std;

Hash::Hash()
{

}

Hash::Hash(unsigned _size)
{
	
}

